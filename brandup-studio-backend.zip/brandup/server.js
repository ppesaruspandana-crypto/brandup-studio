require('dotenv').config();
const express = require('express');
const rateLimit = require('express-rate-limit');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();
const client = new Anthropic(); // reads ANTHROPIC_API_KEY from .env
const MODEL = process.env.MODEL || 'claude-sonnet-5-5';

app.use(express.json({ limit: '10kb' }));
app.use(express.static('public')); // serves your website

// Max 10 generations per IP per minute, so nobody can drain your credits
app.use('/api/', rateLimit({ windowMs: 60_000, max: 10 }));

const SHAPE = '{"hooks":[5 strings],"script":{"hook":"","main":"","cta":"","lines":[{"time":"0-3s","text":""}]},"shots":[{"scene":1,"time":"","visual":"","text":"","voiceover":"","editing":""}],"captions":[3 strings],"hashtags":[8 strings],"ctas":[3 strings]}';

const clean = (s, n = 200) => String(s ?? '').slice(0, n).trim();

app.post('/api/generate', async (req, res) => {
  const b = req.body || {};
  const v = {
    aud: clean(b.aud), plat: clean(b.plat), goal: clean(b.goal),
    tone: clean(b.tone), lang: clean(b.lang, 50), topic: clean(b.topic, 300),
    dur: [15, 30, 45, 60].includes(+b.dur) ? +b.dur : 30,
  };
  if (!v.topic || !v.aud || !v.lang) return res.status(400).json({ error: 'Missing fields' });

  const prompt = `You are a short-form video strategist. Create content for ${v.plat}. Audience: ${v.aud}. Goal: ${v.goal}. Topic: ${v.topic}. Tone: ${v.tone}. Length: ${v.dur} seconds. Write all content in ${v.lang}. Make timestamps cover exactly 0 to ${v.dur}s, with 3-6 scenes. Hooks must be under 15 words and varied. Return ONLY JSON in this shape: ${SHAPE}`;

  try {
    const msg = await client.messages.create({
      model: MODEL,
      max_tokens: 3000,
      messages: [{ role: 'user', content: prompt }],
    });
    const text = msg.content.map(c => c.text || '').join('').replace(/```json|```/g, '').trim();
    res.json(JSON.parse(text));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Generation failed' });
  }
});

app.listen(process.env.PORT || 3000, () =>
  console.log(`Running at http://localhost:${process.env.PORT || 3000}`));
